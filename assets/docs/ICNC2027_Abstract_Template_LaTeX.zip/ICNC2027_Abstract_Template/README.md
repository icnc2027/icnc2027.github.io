# ICNC 2027 abstract template

The complete abstract must fit on **one page**, including the title, authors, affiliations, any images, and references.

Upload this ZIP to Overleaf, set `main.tex` as the main document, and compile with **pdfLaTeX**. Replace the author fields and abstract text. Keep `icnc2027.sty` in the project.

Replace the sample entry in `references.bib` and cite your entries with `\cite{key}`, as demonstrated in the abstract. The References section is enabled by default.

For a local build:

```bash
latexmk -pdf main.tex
```

`main.pdf` previews the template.
